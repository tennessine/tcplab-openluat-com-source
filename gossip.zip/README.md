运行：nohub ./gossip >> gossip.log 2>&1 &

可以指定ip和port参数

nohub ./gossip -ip 123.45.678.9 -port 1234 >> gossip.log 2>&1 &

源码文件是：gossip.go

static目录是前端页面
go.mod、go.sum是go语言项目的依赖

开发需要先安装golang环境
修改gossip.go之后重新生成二进制, 可以执行：CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build